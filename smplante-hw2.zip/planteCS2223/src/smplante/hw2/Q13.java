package smplante.hw2;

public class Q13 {
	
	static public int deckCounter(int max_rank) {
	MyDeck deck = new MyDeck();
	int counter =  0;
	deck = new MyDeck(max_rank);
	deck.in();
	counter++;
	while(!deck.isInReverseOrder()) {
		deck.in();
		counter++;
	}
		return counter;
	}
	
	public static void main(String[]args) {
		System.out.println("max_rank     #in()");
		int max_rank = 13;
		while(max_rank == 13) {
			System.out.println(max_rank + "\t\t" + deckCounter(max_rank));
			max_rank++;
		}
	}

}
