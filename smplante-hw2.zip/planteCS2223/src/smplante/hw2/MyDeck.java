package smplante.hw2;

import algs.days.day06.BagInHalf;
import algs.hw2.Card;
import algs.hw2.Deck;
import algs.hw2.Node;
import algs.hw2.Suit;

/**
 * COPY THIS CLASS into your development area and complete it.
 * @author Home
 *
 */
public class MyDeck extends Deck {
	
	/**
	 * Ensure that no one OUTSIDE of this class invokes the no-argument constructor. You will find
	 * it useful to have this constructor within the copy() method since it must return an accurate
	 * copy of the current Deck, and it will first need to construct an "empty" MyDeck object
	 * without using the MyDeck(int max_rank) constructor.
	 * 
	 */
	protected MyDeck() {
		// You do not need to modify this method. This constructor exists to ensure that 
		// within this class, you can construct an empty MyDeck whose first and last are null.
	}
	
	/** 
	 * Construct a playing deck with {max_rank} cards in specific order.
	 * 
	 * Once done, the linked list of card Nodes must represent a deck that looks like the following (if 
	 * {max_rank} were 3). The suites are ordered Club < Diamond < Hearts < Spades.
	 * 
	 * AC -> 2C -> 3C -> AD -> 2D -> 3D -> AH -> 2D -> 3H -> AS -> 2S -> 3S
	 * 
	 * Note your deck will have 4*{max_rank} cards.
	 * 
	 * Performance must be O(N) where N is max_rank.
	 */
	
	int maximum_rank;
	
	public MyDeck(int max_rank) {
		maximum_rank = max_rank;
		if (max_rank < Card.ACE || max_rank > 22) { throw new IllegalArgumentException("max_rank must be between " + Card.ACE + " and " + Card.KING + " respectively"); }
		
		Card card = new Card(Suit.CLUBS, Card.ACE);//starting card always
		
		Node deckfirst = new Node(card);
		first = deckfirst;

		int counter = 0;
		int rank = 1; //already have the ACE card
		while(counter < max_rank*4) {
			
			if(counter != 0) { //ACE Card
			deckfirst.next = new Node(card);
			deckfirst = deckfirst.next;
					
			if(counter < max_rank*4)
				deckfirst.card = new Card(Suit.CLUBS, rank);
			if(counter >= max_rank && counter < max_rank*2)
				deckfirst.card = new Card(Suit.DIAMONDS, rank);
			if(counter >=max_rank*2 && counter < max_rank*3)
				deckfirst.card = new Card(Suit.HEARTS, rank);
			if(counter >=max_rank*3)
				deckfirst.card = new Card(Suit.SPADES, rank);
			}
			counter++;
			
			rank++;
			
			if(rank > max_rank)
				rank = 1; //resetting the rank value if it is greater than the max_rank
		}
		last = deckfirst;
	}

	@Override
	public Card peekTop() {
		return first.card;
	}

	@Override
	public Card peekBottom() {
		return last.card;
	}

	@Override
	public boolean match(Card c, int n) { 
		int ncounter = 1;
		Node currentnode = first;
		currentnode.card = first.card;
		while(currentnode.next != null) {
			if(currentnode.card.equals(c))
				break;
			currentnode = currentnode.next;
			ncounter++;
		}
		if(ncounter == n)
			return true;
		else
			return false;
	}
	
	@Override 
	public MyDeck copy() { 
		MyDeck copy = new MyDeck(); //creating the copy deck
		Node currentnode = first;
		int counter = 1;
		Node copynode = new Node(currentnode.card);
		while(currentnode != null) { //going through each of the values
			
			if(counter == maximum_rank*4 || currentnode.next == null) {//last node
				copy.last = copynode;
				break;
			}
			
			currentnode = currentnode.next; //advancing the node to be copied by 1
			copynode.next = new Node(currentnode.card); //setting this node as the next for copynode to copy
			
			if(counter == 1) {//first node
				copy.first = copynode;
			}
			
			copynode = copynode.next; //moving to the next to copy
			counter++;
			
		}
		return copy;
	}

	@Override
	public int size() { 
		return maximum_rank*4;
	}

	@Override
	protected Node cutInHalf() { //bottom half "returned"
		if(this.size()%2 != 0) //if odd number of cards in deck
			throw new RuntimeException("Odd Number");
		
		Node firstnode = first;
		Node secondnode = first;
		
		while (firstnode != null) { 
			secondnode = secondnode.next; 
			
			if (secondnode == null || secondnode.next == null) {
				return firstnode.next;
			}
		
			secondnode = secondnode.next;
			firstnode = firstnode.next; 
		}
		return null;
		
		
	}

	@Override
	public void out() {
		Node left = first;
		Node right = cutInHalf();
		this.first = null;
		this.last = null;
		
		Node currentnode = new Node(left.card);
		int counter = 1;

		while(right != null && left != null) {
			if(counter == 1) {
				first = currentnode;
				left = left.next;
				counter++;
			}
			
			if(counter%2 == 0) {//counter is even-right
				currentnode.next = right;
				currentnode = currentnode.next;
				right = right.next;
				
			}
			else { //counter is odd-left
				currentnode.next = left;
				currentnode = currentnode.next;
				left = left.next;
			}
			
		    counter++;
		}
		last = currentnode;
	}
	
	@Override
	public void in() {
		Node left = first;
		Node right = cutInHalf();
		this.first = null;
		this.last = null;
		
		Node currentnode = new Node(right.card);
		int counter = 1;
		
		while(right != null && left != null) {
			if(counter == 1) {
				first = currentnode;
				right = right.next;
				counter++;
			}
			
			
			if(counter%2 != 0) {//counter is odd-right
				currentnode.next = right;
				currentnode = currentnode.next;
				right = right.next;
				
			}
			else { //counter is even-left
				currentnode.next = left;
				currentnode = currentnode.next;
				left = left.next;
			}
			
			
		    counter++;
		}
		currentnode.next = new Node(left.card);
	}

	@Override
	public String representation() {
		String representation = "";
		Node currentnode = first;
		while(currentnode != null) {
			representation = representation + " " + currentnode.card;
			currentnode = currentnode.next;
		}
		
		return representation;
	}
	
	@Override
	public boolean isInOrder() {
		Node currentnode = first;
		Node secondnode = first.next;
		
		while(secondnode.next != null) {
			int difference = currentnode.card.compareTo(secondnode.card);
			if(difference > 0)
				return false;	
			currentnode= currentnode.next;
			secondnode= secondnode.next;
		}
		return true;
	}

	@Override
	public boolean isInReverseOrder() {
		Node currentnode = first;
		Node secondnode = first.next;
		
		while(secondnode.next != null) {
			int difference = currentnode.card.compareTo(secondnode.card);
			if(difference < 0)
				return false;	
			currentnode= currentnode.next;
			secondnode= secondnode.next;
		}
		return true;
	}
	
	public static void main(String[]args) {
		MyDeck deck = new MyDeck(2);
		System.out.println("Representation: " + deck.representation());
	}
}

