package smplante.hw2;

public class Q12 {
	
	static public int deckCounter(int max_rank) {
	MyDeck deck = new MyDeck();
	int counter =  0;
	deck = new MyDeck(max_rank);
	deck.out();
	counter++;
	
	while(!deck.isInOrder()) {
		deck.out();
		counter++;
	}
		return counter;
	}
	
	public static void main(String[]args) {
		System.out.println("max_rank     #out()");
		int max_rank = 1;
		while(max_rank < 22) {
			System.out.println(max_rank + "\t\t" + deckCounter(max_rank));
			max_rank++;
		}
	}
}
