package smplante.hw2;

public class Q11 {
	
	static public int deckCounter(int max_rank) {
	MyDeck deck = new MyDeck();
	int counter =  0;
	deck = new MyDeck(max_rank);
	deck.in();
	counter++;
	
	while(!deck.isInOrder()) {
		deck.in();
		counter++;
	}
		return counter;
	}
	
	public static void main(String[]args) {
		System.out.println("max_rank\t#in()");
		int max_rank = 1;
		while(max_rank < 22) {
			System.out.println(max_rank + "\t\t" + deckCounter(max_rank));
			max_rank++;
		}
	}
}
