package smplante.hw1;

import algs.hw1.*;
import algs.hw1.api.*;

public class ManhattanSquareFinder implements IManhattanSquareFinder {

	/** 
	 * Return the Coordinate of location in ManhattanSquare containing target.
	 * 
	 * You can inspect the contents of the array for ms using the distance() method.
	 */
	public Coordinate find(ManhattanSquare ms, int target) {
		Coordinate coordinates = null;
		
		int distance = ms.distance(0, 0, target); //first probe to find diagonal
		
		if(distance == 0) {
			coordinates = new Coordinate(0,0);
			return coordinates;
		}
		
		int rowcount;
		int columncount;
		
		if(distance >= ms.N-1) {
			rowcount = ms.N-1;
			columncount = distance - ms.N + 1;
		}
		
		else {
			rowcount = distance; //if distance is less than the ms.N value
			columncount = 0;
		}
			
		int distance2 = ms.distance(rowcount, columncount, target); //second probe to find coordinates
		
		if(distance2 == 0) {
			coordinates = new Coordinate(rowcount, columncount);
			return coordinates;
		}
		
		for(int i = 2; i<(ms.N * 2) - 1; i++) {
			int coordchange = i/2;
			if(distance2 == i) {
				coordinates = new Coordinate(rowcount - coordchange, columncount + coordchange);
				return coordinates;
			}
		}
		
		//use distance formula??
		//know how many steps by 2 to get along diagonal y = 2x
		//know point of origin
		
		return coordinates;
		
	}
	
	
	// You do not need to modify below this line.
	// ------------------------------------------
	public static void main(String[] args) {	
		
		for (int n = 1; n < 20; n++) {
			ManhattanSquare ms = new ManhattanSquare(n, 99);
			int numProbes = ms.solver(new ManhattanSquareFinder());
			System.out.println(n + "\t" + numProbes);
		}
	}
}
