package smplante.hw1;

import algs.hw1.*;
import algs.hw1.api.*;

/**
 * Copy this class into your USERID.hw1 package and complete it.
 */
public class FuzzyFinder implements IFuzzySquareFinder {

	/**
	 * Return the Coordinate(r,c) where target exists. If it is not in 
	 * the 2D array, return null.
	 * 
	 * You can inspect the contents of the array for fs using the probe3x3() method.
	 */
	
	//helper function to search through the smaller probed area
	public Coordinate helper(FuzzySquare fs, int i, int j, int target) {
		Coordinate coordinates = null;
		
		//smaller probe
		if(fs.probe3x3(i, j+2, target)==0) {
			if(fs.probe3x3(i+2, j+2, target)==0) {
				coordinates = new Coordinate (i+1, j+1);
			}
			else if(fs.probe3x3(i+1, j+2, target)==0) {
				coordinates = new Coordinate (i, j+1);
			}
			else if(fs.probe3x3(i, j+2, target)==0) {
				coordinates = new Coordinate (i-1, j+1);
			}
		}
		else if(fs.probe3x3(i, j+1, target)==0) {
			if(fs.probe3x3(i+2, j+1, target)==0) {
				coordinates = new Coordinate (i+1, j);
			}
			else if(fs.probe3x3(i+1, j+1, target)==0) {
				coordinates = new Coordinate (i, j);
			}
			else if(fs.probe3x3(i, j+1, target)==0) {
				coordinates = new Coordinate (i-1, j);
			}
		}
		else if(fs.probe3x3(i, j, target)==0) {
			if(fs.probe3x3(i+2, j, target)==0) {
				coordinates = new Coordinate (i+1, j-1);
			}
			else if(fs.probe3x3(i+1, j, target)==0) {
				coordinates = new Coordinate (i, j-1);
			}
			else if(fs.probe3x3(i, j, target)==0) {
				coordinates = new Coordinate (i-1, j-1);
			}
		}
		
		return coordinates;
	}
	
	public Coordinate find(FuzzySquare fs, int target) {
		Coordinate coordinates = null;
		
		if(fs.N%2 != 0) { //odd-sized array- skips every other col/row when doing general probe to save probes
		for(int i = 1; i<fs.N-1; i+=2) { //first probe to find the general 3x3 area where target is
			for(int j = 1; j<fs.N-1;j+=2) {
				if(fs.probe3x3(i, j, target) == 0) {   //target found in probing area
					coordinates = helper(fs,i,j,target);
				}
			}
		}
		}
		
		else { //even-sized array- goes through each col/row to make sure none are missed
			for(int i = 1; i<fs.N-1; i++) { //first probe to find the general 3x3 area where target is
				for(int j = 1; j<fs.N-1;j++) {
					if(fs.probe3x3(i, j, target) == 0) {   //target found in probing area
						coordinates = helper(fs,i,j,target);
					}
				}
			}
			}
		
		return coordinates;
	}	

	// You do not need to modify below this line.
	// ------------------------------------------
	public static void main(String[] args) {
		
		for (int i = 5; i < 40; i++) {
			FuzzySquare fs = new FuzzySquare(i, 99);
			fs.solver(new FuzzyFinder());
			System.out.println(i + "\t" + fs.getNumProbes());
		}
	}
}
