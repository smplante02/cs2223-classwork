Resources to use for Homework 1

DO NOT MAKE MODIFICATIONS HERE! 

When you copy these files into your directory, be sure you place them in 
a package USERID.hw1 so the TAs will be quickly able to see/find your files.

If you have questions as to how to structure your code in this way, come to office hours.

Note that the file WrittenQuestions.txt is where you should add your answers to the homework
that require written answers.

