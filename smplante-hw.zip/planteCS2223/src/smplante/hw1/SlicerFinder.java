package smplante.hw1;

import algs.hw1.*;
import algs.hw1.api.*;

public class SlicerFinder implements ISlicerFinder {
	
	public Coordinate find(Slicer s, int target) {
		int vertical = -1; //initial values
		int horizontal = -1;
		Coordinate coordinates = null;
		
		for(int i = 0; i< s.N; i++) { //looking top-down through the array
			if(s.inTop(i, target)) {
				vertical = i;
				break;
			}
		}
			
		for(int j = 0; j<s.N; j++) { //looking left-over through the array
			if(s.inLeft(j, target)) {
				horizontal = j;
				break;
			}
		}
		coordinates = new Coordinate (vertical, horizontal);//setting the final coordinate
		if(vertical == -1 || horizontal == -1) {
			return null;
		}
		
		else {
			return coordinates;
		}
	}	

	// You do not need to modify below this line.
	// ------------------------------------------
	public static void main(String[] args) {
		for (int i = 1; i < 20; i++) {
			Slicer s = new Slicer(i, 99);
			s.solver(new SlicerFinder());
		
			System.out.println(i + "\t" + s.getNumProbes());
		}
		System.out.println();
		
		for (int n = 1; n < 65; n*=2) {
			Slicer s = new Slicer(n, 99);
			int numProbes = s.solver(new SlicerFinder());
			System.out.println(n + "\t" + numProbes);
		} 
	}
}
