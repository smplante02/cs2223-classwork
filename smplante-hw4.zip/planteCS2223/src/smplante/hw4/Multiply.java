package smplante.hw4;

// Question 1. complete this class. It must extend Expression
public class Multiply extends Expression{
	final Expression left;
	final Expression right;
	
	public Multiply(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}
	
	@Override
	public double eval() {
		return left.eval() * right.eval();
	}

	@Override
	public String format() {
		return String.format("(%s*%s)", left.format(), right.format());
	}
	
	public int height() {
		if(this.left == null && this.right == null)
			return 1;
		
		int leftheight = left.height();
		int rightheight = right.height();
		
		if(leftheight > rightheight)
			return leftheight + 1;
		else
			return rightheight + 1;
	}
}
