package smplante.hw4;

import edu.princeton.cs.algs4.*;

/**
 * How many random directed graphs of V vertices have a cycle? and are connected?
 * 
 * Create a random graph by adding an edge between two vertices u and v with a probability
 * of 50%.
 * 
 * Run the same trial, this time using graphs whose edges each have a probability of 1/N chance
 * of being present.
 */
public class Q3 {
	
	static Digraph graphHelper(boolean one, int N){
		Digraph graph = new Digraph(N);
		for(int j = 0; j < N; j++) {
			for(int k = 0; k < N; k++) {
				if(one == true) {
				if(Math.random() < 0.5 && j != k)
					graph.addEdge(j, k);
				}
				if (one == false) {
					if(Math.random() < 1.0/N && j != k)
						graph.addEdge(j, k);
				}
			}
		}
		return graph;
	}

	public static void main(String[] args) {
		System.out.println("For 0.5");
		System.out.println("N\tN# Cycles\t#Connected");
		
		//first
		for(int N = 2; N < 15; N++) {
			int numCycles = 0;
			int numConnected = 0;
			
			for(int i = 0; i< 10000; i++) { //creating 10,000 graphs
				Digraph graph = graphHelper(true, N); 		
				
				//to find cycles
				DirectedCycle directedCycle = new DirectedCycle(graph);
				if(directedCycle.hasCycle())
					numCycles++;
				
				//to find connected
				DirectedDFS DFS = new DirectedDFS(graph, 0); //starting from vertex 0;
				boolean connected = true; 
				
				for(int j = 0; j < graph.V(); j++) {
					if(!DFS.marked(j)) //if there isn't a path between 0 and the current vertex
						connected = false;
				}
				
				if(connected)
					numConnected++;
			}
			
		System.out.println(N + "\t" + numCycles + "\t\t" + numConnected);
		}
		
		System.out.println("\n");
		
		System.out.println("For 1.0/N");
		System.out.println("N\tN# Cycles\t#Connected");
		
		//second
			for(int N = 2; N < 15; N++) {
				int numCycles = 0;
				int numConnected = 0;
					
				for(int i = 0; i< 10000; i++) { //creating 10,000 graphs
					Digraph graph = graphHelper(false, N); 		
						
					//to find cycles
					DirectedCycle directedCycle = new DirectedCycle(graph);
					if(directedCycle.hasCycle())
						numCycles++;
					
					//to find connected
					DirectedDFS DFS = new DirectedDFS(graph, 0); //starting from vertex 0;
					boolean connected = true; 
						
					for(int j = 0; j < graph.V(); j++) {
						if(!DFS.marked(j)) //if there isn't a path between the source vertex and the current vertex
							connected = false;
					}
					
					if(connected)
						numConnected++;
				}
					
			System.out.println(N + "\t" + numCycles + "\t\t" + numConnected);
			}		
		
	}
	
}
