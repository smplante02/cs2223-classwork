package smplante.hw5;

import java.io.FileNotFoundException;
import java.util.Scanner;

// use any classes from Sedgewick...
import edu.princeton.cs.algs4.*;

// Note that the Day18 implementation of AVL removes <Key,Value> and only uses <Key>
import algs.days.day18.AVL;
import algs.hw5.Dictionary;

/**
 * Copy this class into your project area and modify it for problem 1 on HW5.
 */
public class WordZipper {

	/**
	 * Represent the mapping of (uniqueID, 3- and 4-letter words) from String <-> Integer where Integer is vertex id
	 */
	static SeparateChainingHashST<String,Integer> map = new SeparateChainingHashST<String,Integer>();
	static SeparateChainingHashST<Integer,String> reverse = new SeparateChainingHashST<Integer,String>();

	/** Store all three-letter and four-letter words (in lowercase). */
	static AVL<String> avl; 
	
	
	
	/**
	 * Return a Queue of words that result by adding a single letter to the three letter word.
	 * 
	 * There are 4*26 possible words that could result by adding a single letter (a-z) at each of the 
	 * four possible spots
	 * 
	 *      E A T
	 *      
	 *     SEAT
	 *      ERAT
	 *       EAST
	 *        EATS
	 *        
	 * It is acceptable for this method to return duplicates in the queue.
	 * 
	 * For example, if the word is "BET" then it could include in its response
	 * "BEET" (where the E is inserted between the B and E) and "BEET" (where
	 * the E is inserted between the E and the T).
	 */
	public static Queue<String> addOne(String three) {
		if(three.length() == 4) //can't add more if there are already 4 letters
			return null;
		Queue<String> posWords = new Queue<String>();
		String[] letters = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
		for(int spots = 0; spots < 4; spots++) {
			for(int i = 0; i < 26; i++) {
				String copyString = new String();
				copyString = three.substring(0, spots) + letters[i] + three.substring(spots); //inserting between substrings
				
				for(String key: avl.keys()) {
					if(copyString.equals(key)) {
						posWords.enqueue(key);
					}
					
				}
			}
		}
		return posWords;
	}

	/**
	 * Return valid words by removing one of the four letters.
	 * 
	 * It is acceptable for this method to return duplicates in the queue.
	 * For example, if the word is 'BEET' then the words returned could 
	 * be {"BEE", "BET", "BET"}
	 */
	public static Queue<String> removeOne(String four) {
		if(four.length() == 3) //can't remove if there are only 3 letters
			return null;
		
		Queue<String> posWords = new Queue<String>();
		for(int spots = 0; spots < 4; spots++) {
			String copyString = new String();
			for(int i = 0; i < 4; i++) {
				if(i != spots)
					copyString += four.charAt(i);
			}
			
			for(String key: avl.keys()) {
				if(copyString.equals(key))
					posWords.enqueue(key);
			}
		}
		
		return posWords;
	}
	
	/**
	 * Main method to execute.
	 *
	 * From console, enter the start and end of the word ladder.
	 */
	public static void main(String[] args) throws FileNotFoundException {

		// Use this to contain all three- and four-letter words that you find in dictionary
		avl = new AVL<String>();

		// Construct AVL tree of all three- and four-letter words.
		// Note: you will have to copy this file into your project to access it.
		Scanner sc = Dictionary.words();
		
		// now construct graph, where each node represents a word, and an edge exists between
		// two nodes if their respective words are off by a single letter. Hint: use the
		// keys() method provided by the AVL tree. Your graph will be an undirected graph.
		int counter = 0;
		while(sc.hasNext()) {
			String potentialWord = sc.nextLine();
			if(potentialWord.length()== 4 || potentialWord.length() == 3) {
				avl.insert(potentialWord);
				map.put(potentialWord, counter);
				reverse.put(counter, potentialWord);
				counter++;
			}
		}
		
		//making the graph edges
		Graph G = new Graph(map.size());
		int[][] ij = new int[map.size()][map.size()]; //to store duplicates
		for(int i: reverse.keys()) {
			Queue<String> compareQueue;
			if(reverse.get(i).length() == 3) //checking to see if we have to add or take away a letter
				compareQueue = addOne(reverse.get(i));
			else
				compareQueue = removeOne(reverse.get(i));
			
				while(!compareQueue.isEmpty()) {
					String compareString = compareQueue.dequeue();
					if(ij[i][map.get(compareString)] != 1 && ij[map.get(compareString)][i] != 1)
						G.addEdge(i, map.get(compareString));
						ij[i][map.get(compareString)] = 1; //to make sure that no duplicates are added
						ij[i][map.get(compareString)] = 1;
					}
				}
				
		sc.close();  // once done, you can close this resource.
		
		// this loop will complete when the user enters in a non-word.
		while (true) {
			StdOut.println("Enter word to start from (all in lower case):");
			String start = StdIn.readString().toLowerCase();
			StdOut.println("Enter word to end at (all in lower case):");
			String end = StdIn.readString().toLowerCase();
	
			// need to validate that these are both actual four-letter words in the dictionary
			if (!avl.contains(start)) {
				StdOut.println (start + " is not a valid word in the dictionary.");
				System.exit(-1);
			}
			if (!avl.contains(end)) {
				StdOut.println (end + " is not a valid word in the dictionary.");
				System.exit(-1);
			}
			
			// Once both words are known to exist in the dictionary, then create a search
			// that finds shortest distance (should it exist) between start and end.
			// be sure to output the words in the word zipper, IN ORDER, from the start to end.
			// IF there is no word zipper possible, then output "NONE POSSIBLE."
			
			//get BFP from starting point
			//if no path, then output "NONE POSSIBLE"
			
			BreadthFirstPaths pathToEnd = new BreadthFirstPaths(G, map.get(start));
			Iterable<Integer> integer = pathToEnd.pathTo(map.get(end));
			for(int i: integer) {
				System.out.print(reverse.get(i) + " "); 
			}
			
			
			
			
		}
		
	}
}
