package smplante.hw3;

import edu.princeton.cs.algs4.StdRandom;

public class Q4 {
	public static void trying(){
		int currentmaxHeight = -1;
	for (int N = 1; N <= 40; N++) { //for each value of N
		int counter = 0;
		int maxHeight = 0;
		
		for(int numberofbst = 1; numberofbst <= 10000; numberofbst++) { //doing making the AVL tree 10,000 times
			AVL<Integer> avl = new AVL<Integer>();
			for(int i = 0; i < N; i++) { //making the AVL tree with random values
				avl.insert(StdRandom.uniform(128));
			}
			int currentmax = avl.dynamicHeight(avl.root);
			
			if(maxHeight < currentmax) {
				maxHeight = currentmax;
				counter = 0; //resets counter back
				}
			
			if(currentmax == maxHeight)
				counter++;
			
		}
		if(currentmaxHeight != maxHeight)
			System.out.println(N + "\t" + maxHeight + "\t\t\t" + counter);
		currentmaxHeight = maxHeight;
		
	}
	}
	
	
	public static void main(String[]args) {
		System.out.println("N\tLargest Height\t\tNumber Found");
		trying();
	}
}
