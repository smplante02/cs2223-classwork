package smplante.hw3;

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StopwatchCPU;
import algs.days.day16.ComparableTimSort;
import algs.hw3.CountedItem;
import algs.hw3.PrimitiveTimSort;

/**
 * 
 * Use the existing SortTrial class, and write your own for your implementation
 * of TimSort and also the HeapSort 
 * 
 * https://shakespeare.folger.edu/shakespeares-works/hamlet/download/
 * 
 * What is the longest word which is not a modern English word, according to
 * our dictionary?
 */
public class Q1 {
	
	/** Return time to sort array using merge sort. */
	public static double mergeSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU(); 
		edu.princeton.cs.algs4.Merge.sort(A);
		return start.elapsedTime();
	}
	
	/** Return time to sort array using quick sort. */
	public static double quickSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU();
		edu.princeton.cs.algs4.Quick.sort(A);
		return start.elapsedTime();
	}
	
	/** Return time to sort array using Insertion Sort. */
	public static double insertionSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU();
		edu.princeton.cs.algs4.Insertion.sort(A);
		return start.elapsedTime();
	}
	
	/** Return time to sort array using Selection Sort. */
	public static double selectionSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU();
		edu.princeton.cs.algs4.Selection.sort(A);
		return start.elapsedTime();
	}
	
	/** Return time to sort array using Heap Sort. */
	public static double heapSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU();
		edu.princeton.cs.algs4.Heap.sort(A);
		return start.elapsedTime();
	}
	
	/** Return time to sort array using Primitive Tim Sort. */
	public static double primitiveTimSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU();
		PrimitiveTimSort.sort(A);
		return start.elapsedTime();
	}
	
	/** Return time to sort array using Optimized Tim Sort. */
	public static double builtinSort(Comparable<?>[] A) {
		StopwatchCPU start = new StopwatchCPU();
		ComparableTimSort.sort(A);
		return start.elapsedTime();
	}

	/** 
	 * Given a sorted array of CountedItem<String> objects, ensure that for 
	 * any two index positions, i and j, if A[i] is equal to A[j] and i < j, 
	 * then A[i].earlier(A[j]) is true.
	 * 
	 * Performance must be O(N).
	 */
	public static boolean isSortedArrayStable(CountedItem<Integer>[] A) {
		for(int i = 0; i<A.length-1; i++) {
			if(A[i].equals(A[i+1]) && !A[i].earlier(A[i+1])) return false;
			}
		return true;
	}
	
	/** 
	 * Given an array of integers, return a CountedItem<Integer> array. If you construct
	 * and add the objects from left to right, then for two duplicate values A[i] and A[j],
	 * you know that the counter for A[i] is smaller than the counter for A[j] if i < j. 
	 */
	static CountedItem<Integer>[] toCountedArray(Integer vals[]) {
		CountedItem<Integer>[] copy = new CountedItem[vals.length];
		for (int i  = 0; i < copy.length; i++) {
			copy[i] = new CountedItem<>(vals[i]);
		}
		
		return copy;
	}
	
	public static void trial1_1() {
		System.out.println("Q1.1");
		
		Integer vals[] = new Integer[4096]; 
		
		for (int i = 0; i < vals.length; i++) { 
			vals[i] = StdRandom.uniform(128); 
			}
		System.out.println();
		CountedItem<Integer>[] heapArray = toCountedArray(vals);
		CountedItem<Integer>[] insertionArray = toCountedArray(vals);
		CountedItem<Integer>[] mergeArray = toCountedArray(vals);
		CountedItem<Integer>[] quickArray = toCountedArray(vals);
		CountedItem<Integer>[] selectionArray = toCountedArray(vals);
		CountedItem<Integer>[] timmyArray = toCountedArray(vals);
		CountedItem<Integer>[] timArray = toCountedArray(vals);
		
		
		System.out.println("Algorithm\t\tStable Sort");
		edu.princeton.cs.algs4.Heap.sort(heapArray); //unstable
		System.out.println("HeapSort" + "\t\t" + isSortedArrayStable(heapArray));
		
		edu.princeton.cs.algs4.Insertion.sort(insertionArray);
		System.out.println("InsertionSort:" + "\t\t" + isSortedArrayStable(insertionArray));
		
		edu.princeton.cs.algs4.Merge.sort(mergeArray);
		System.out.println("MergeSort:" + "\t\t" + isSortedArrayStable(mergeArray));
		
		edu.princeton.cs.algs4.Quick.sort(quickArray); //unstable
		System.out.println("QuickSort:" + "\t\t" + isSortedArrayStable(quickArray));
		
		edu.princeton.cs.algs4.Selection.sort(selectionArray); //unstable
		System.out.println("SelectionSort:" + "\t\t" + isSortedArrayStable(selectionArray));
		
		PrimitiveTimSort.sort(timmyArray);
		System.out.println("TimSort Primitive:" + "\t" + isSortedArrayStable(timmyArray));
		
		ComparableTimSort.sort(timArray);
		System.out.println("TimSort Optimized:" + "\t" + isSortedArrayStable(timArray));
	}
	
	//Over the range of N from 1,048,576 to 16,777,216, create an unordered array, A, of N random integers
	//using StdRandom.uniform(N). This array provides the template for launching a trial for each of four
	//efficient sorting techniques (Merge Sort, Heap Sort, Quick Sort, and Tim Sort, both Primitive and
	//Optimized). Copy algs.hw3.submission.Q1 into your USERID.hw3 package.
	
	public static void trial1_2() {
		System.out.println("\nQ1.2");
		
		System.out.print("N\t\tTimO\tMerge\tTimP\tQuick\tHeap");
		for(int N = 1048576; N <= 16777216; N*=2) {
			Integer A[] = new Integer[N];
			for(int i= 0; i<A.length ; i++) {
				A[i] = StdRandom.uniform(N);
			}
			
			Integer[] mergeArray = A.clone();
			Integer[] heapArray = A.clone();
			Integer[] quickArray = A.clone();
			Integer[] timmyArray = A.clone();
			Integer[] timArray = A.clone();
			
			System.out.println();
			
			System.out.print(N);
			
			System.out.print("\t");
			if(N != 16777216)
				System.out.print("\t");
				else
					System.out.print("");
			System.out.printf("%.03f",builtinSort(timArray)); //1
			
			System.out.print("\t");
			System.out.printf("%.03f", mergeSort(mergeArray)); //2
			
			System.out.print("\t");
			System.out.printf("%.03f",primitiveTimSort(timmyArray)); //3
			
			System.out.print("\t");
			System.out.printf("%.03f", quickSort(quickArray)); //4
			
			System.out.print("\t");
			System.out.printf("%.03f",heapSort(heapArray)); //last
			
		}
	}
	
	
	public static void trial1_3() {
		System.out.println("\nQ1.3");
		
		System.out.print("N\t\tTimO\tMerge\tTimP\tQuick\tHeap");
		for(int N = 1048576; N <= 16777216; N*=2) {
			Integer A[] = new Integer[N];
			for(int i= 0; i<A.length ; i++) {
				A[i] = StdRandom.uniform(N/512);
			}
			
			Integer[] mergeArray = A.clone();
			Integer[] heapArray = A.clone();
			Integer[] quickArray = A.clone();
			Integer[] timmyArray = A.clone();
			Integer[] timArray = A.clone();
			
			System.out.println();
			
			System.out.print(N);
			
			System.out.print("\t");
			if(N != 16777216)
			System.out.print("\t");
			else
				System.out.print("");
			System.out.printf("%.03f",builtinSort(timArray)); //1
			
			System.out.print("\t");
			System.out.printf("%.03f",primitiveTimSort(timmyArray)); //2
			
			System.out.print("\t");
			System.out.printf("%.03f", mergeSort(mergeArray)); //3
			
			System.out.print("\t");
			System.out.printf("%.03f", quickSort(quickArray)); //4
			
			System.out.print("\t");
			System.out.printf("%.03f",heapSort(heapArray)); //last
		}
	}
	
	public static void trial1_4() {
		System.out.println("\nQ1.4");
		
		System.out.print("N\t\tTimO\tMerge\tTimP\tHeap\tQuick");
		for(int N = 1048576; N <= 16777216; N*=2) {
			Integer A[] = new Integer[N+1];
			for(int i = 0; i < A.length; i++) {
				A[i] = N-i;
			}
			
			Integer[] mergeArray = A.clone();
			Integer[] heapArray = A.clone();
			Integer[] quickArray = A.clone();
			Integer[] timmyArray = A.clone();
			Integer[] timArray = A.clone();
			
			System.out.println();
			
			System.out.print(N);
			
			System.out.print("\t");
			if(N != 16777216)
			System.out.print("\t");
			else
				System.out.print("");
			System.out.printf("%.03f",builtinSort(timArray)); //1
			
			System.out.print("\t");
			System.out.printf("%.03f", mergeSort(mergeArray)); //2
			
			System.out.print("\t");
			System.out.printf("%.03f",primitiveTimSort(timmyArray)); //3
			
			System.out.print("\t");
			System.out.printf("%.03f",heapSort(heapArray)); //4
			
			System.out.print("\t");
			System.out.printf("%.03f", quickSort(quickArray)); //last
		}
	}
	
	public static void main(String[] args) {
		trial1_1();
		trial1_2();
		trial1_3();
		trial1_4();
	}
}
