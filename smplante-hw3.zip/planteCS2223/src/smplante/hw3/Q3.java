package smplante.hw3;

public class Q3 {
	
	static String mostcommon;
	
	public static void mostcommonoverall() {
		BST mostcommonbst = new BST();
		BST perplay = new BST(); 
		for(int i = 1; i <= 38; i++) { 
			ShakespearePlay play = new ShakespearePlay(i); //getting each play
			
			for(String s:play) {
				if(perplay.get(s) == null) { //if nothing there
					perplay.put(s, 1); //adding with a count of 1
				}
				
				else {
					perplay.put(s, perplay.get(s)+1); //updating the count by +1
				}
				
				mostcommonbst.put(perplay.mostFrequent(), perplay.get(perplay.mostFrequent()) + 1);
			}
		
		}
		
		System.out.println("Most common in all plays: " + mostcommonbst.mostFrequent()); //finding the most common out of all of them
		mostcommon = mostcommonbst.mostFrequent();
	}
	
	public static void mostcommonperplay() {
		for(int i = 1; i <= 38; i++) {//for each play
			BST perplay = new BST();
			ShakespearePlay play = new ShakespearePlay(i); //getting each play
			
			for(String s:play) {
				if(perplay.get(s) == null) { //if it's not there
					perplay.put(s, 1); //adding with a count of 1
				}
				else {
					perplay.put(s, perplay.get(s)+1); //updating the count by +1
				}
			}
			
		String first = perplay.mostFrequent();
		perplay.delete(first);
			
		String second = perplay.mostFrequent();
		perplay.delete(second);
			
		String third = perplay.mostFrequent();
		perplay.delete(third);
			
		String fourth = perplay.mostFrequent();
		perplay.delete(fourth);
			
		String fifth = perplay.mostFrequent();
		perplay.delete(fifth);
			
		if(!first.equals(mostcommon) && !second.equals(mostcommon) && !third.equals(mostcommon) && !fourth.equals(mostcommon) && !fifth.equals(mostcommon))
			System.out.println(play.title + " does not contain " + mostcommon + " as one of its most common words!");
		System.out.println(first + "\t" + second + "\t" + third + "\t" + fourth + "\t" + fifth + "\t" + play.title);
			
		}
		
	}
	
	public static void longestword() {
		String longestword = "";
		for(int i = 1; i <= 38; i++) { 
			ShakespearePlay play = new ShakespearePlay(i); //getting each play
			
			for(String s:play) {
				if(s.length() > longestword.length() && !s.contains("-"))
					longestword = s;
			}
		
		}
		
		System.out.println(longestword + " is the longest word!");
	}
	
	
	public static void main(String[]args) {
		//mostcommonoverall();
		//System.out.println("Most common per play:");
		//mostcommonperplay();
		//longestword();
	}
}

