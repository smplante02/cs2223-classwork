package smplante.hw3;

/**
 * Bonus question only.
 */
public class FibonacciTree {

	class Node {
		int    key;          
		Node   left, right;  // left and right subtrees

		public Node(int key) {
			this.key = key;
		}
	}

	Node root;

	public FibonacciTree(int N) {

	}
}
